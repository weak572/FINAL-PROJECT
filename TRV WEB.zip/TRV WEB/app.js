
import { renderHome, bindHomeEvents } from "./home.js";
import { PACKAGES, getPackage } from "./data.js";
import {
  getBookings,
  getDepartures,
  formatDate,
  formatDateTime,
  peso,
  createBooking,
  changeStatus,
  downloadRecords,
  STATUSES,
  PAYMENT_METHODS,
  STATUS_TRANSITIONS,
  addOnSummary
} from "./store.js";
import {
  escapeHtml,
  icon,
  packageCard,
  toast
} from "./ui.js";

const app = document.querySelector("#app");

function renderHeader() {
  return `
    <header class="site-header">
      <div class="container header-inner">
        <a class="brand" href="#/home">
          <span class="brand__mark">${icon("compass")}</span>
          <span class="brand__text">
            <span class="brand__name">Nature</span>
            <span class="brand__tag">GATEWAY</span>
          </span>
        </a>

        <nav class="nav-desktop" aria-label="Main navigation">
          <a href="#/home">Home</a>
          <a href="#/tours">Tours</a>
          <a href="#/book">Book a trip</a>
          <a href="#/records">Records</a>
          <a href="#/about">About & Help</a>
        </nav>

        <div class="header-actions">
          <a class="btn btn--outline btn--sm" href="#/my-bookings">
            ${icon("clipboard")} My bookings
          </a>
          <a class="btn btn--sm" href="#/book">
            Plan a trip →
          </a>
        </div>

        <button class="btn btn--outline btn--icon menu-toggle"
          id="menu-toggle" type="button"
          aria-label="Open navigation" aria-expanded="false">
          ${icon("menu")}
        </button>
      </div>

      <div class="mobile-menu" id="mobile-menu" hidden>
        <nav aria-label="Mobile navigation">
          <a href="#/home">Home</a>
          <a href="#/tours">Tours</a>
          <a href="#/book">Book a trip</a>
          <a href="#/records">Records</a>
          <a href="#/about">About & Help</a>
          <a href="#/my-bookings">My bookings</a>
        </nav>
      </div>
    </header>`;
}

function renderFooter() {
  return `
    <footer class="site-footer">
      <div class="container footer-grid">
        <div class="footer-brand">
          <a class="brand" href="#/home">
            <span class="brand__mark">${icon("compass")}</span>
            <span class="brand__text">
              <span class="brand__name">Nature</span>
              <span class="brand__tag">GATEWAY</span>
            </span>
          </a>
          <p>Thoughtfully planned journeys across the Philippines.</p>
        </div>

        <div class="footer-col">
          <h3>Explore</h3>
          <ul>
            <li><a href="#/tours">Tours</a></li>
            <li><a href="#/book">Book a trip</a></li>
            <li><a href="#/records">Records</a></li>
          </ul>
        </div>

        <div class="footer-col">
          <h3>Information</h3>
          <ul>
            <li><a href="#/about">About & Help</a></li>
            <li><a href="#/my-bookings">My bookings</a></li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="container">
          © ${new Date().getFullYear()} Nature Gateway
          <span>Go gently. See deeply. Travel kindly.</span>
        </div>
      </div>
    </footer>`;
}

function getRoute() {
  const hash = window.location.hash.slice(1) || "/home";
  const [path, query = ""] = hash.split("?");
  return {
    page: path.replace("/", "") || "home",
    params: new URLSearchParams(query)
  };
}

function renderTours() {
  return `
    <section class="section page-shell">
      <div class="container">
        <div class="page-heading">
          <p class="eyebrow">Explore the Philippines</p>
          <h1>Our Tours</h1>
          <p>Discover islands, mountains, beaches and local culture.</p>
        </div>

        <div class="card-grid">
          ${PACKAGES.map(packageCard).join("")}
        </div>
      </div>
    </section>`;
}


function getMonthKey(date) {
  return date.slice(0, 7);
}

function getMonthLabel(monthKey) {
  const [year, month] = monthKey.split("-").map(Number);

  return new Date(year, month - 1, 1).toLocaleDateString("en-PH", {
    month: "long",
    year: "numeric"
  });
}

function renderCalendarGrid(pkg, monthKey, selectedDate = "") {
  const departures = getDepartures(pkg);
  const departureMap = new Map(
    departures.map(item => [item.date, item])
  );

  const [year, month] = monthKey.split("-").map(Number);
  const firstDay = new Date(year, month - 1, 1).getDay();
  const daysInMonth = new Date(year, month, 0).getDate();

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const hasDepartures = departures.some(
    item => getMonthKey(item.date) === monthKey
  );

  const monthDepartures = departures.filter(
    item => getMonthKey(item.date) === monthKey
  );

  const allBooked = hasDepartures &&
    monthDepartures.every(item => item.available <= 0 || item.isPast);

  let html = "";

  for (let i = 0; i < firstDay; i++) {
    html += `<span class="calendar-empty"></span>`;
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = [
      year,
      String(month).padStart(2, "0"),
      String(day).padStart(2, "0")
    ].join("-");

    const departure = departureMap.get(date);
    const currentDate = new Date(year, month - 1, day);
    const isPast = currentDate < today;

    let status = "unavailable";
    let disabled = true;
    let detail = "No departure scheduled";

    if (isPast) {
      status = "past";
      detail = "Past date";
    } else if (departure && departure.available <= 0) {
      status = "full";
      detail = "Fully booked";
    } else if (departure && departure.available <= 3) {
      status = "limited";
      disabled = false;
      detail = `${departure.available} seats left`;
    } else if (departure) {
      status = "available";
      disabled = false;
      detail = `${departure.available} seats available`;
    }

    const isSelected = selectedDate === date;

    html += `
      <button
        type="button"
        class="calendar-day calendar-day--${status} ${isSelected ? "is-selected" : ""}"
        data-calendar-date="${date}"
        ${disabled ? "disabled" : ""}
        title="${detail}"
        aria-label="${date}: ${detail}"
        ${isSelected ? 'aria-pressed="true"' : 'aria-pressed="false"'}
      >
        <span>${day}</span>
        ${departure && !isPast
          ? `<small>${departure.available}</small>`
          : ""}
      </button>
    `;
  }

  let monthMessage = "";

  if (!hasDepartures) {
    monthMessage = "No departures scheduled this month.";
  } else if (allBooked) {
    monthMessage = "All scheduled departures this month are fully booked.";
  } else {
    monthMessage = "Choose an available departure date.";
  }

  return `
    <div class="calendar-weekdays">
      ${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        .map(day => `<span>${day}</span>`)
        .join("")}
    </div>

    <div class="calendar-days">
      ${html}
    </div>

    <p class="calendar-message">${monthMessage}</p>
  `;
}


function renderDepartureCalendar(pkg) {
  const today = new Date();

  const currentMonth = [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, "0")
  ].join("-");

  return `
    <div class="departure-calendar" id="departure-calendar">
      <div class="calendar-controls">
        <label for="calendarMonth">Choose month and year</label>
        <input
          class="input"
          type="month"
          id="calendarMonth"
          min="${currentMonth}"
          value="${currentMonth}"
        >
      </div>

      <div id="calendar-grid">
        ${renderCalendarGrid(pkg, currentMonth)}
      </div>

      <div class="calendar-legend">
        <span><i class="legend-dot available"></i> Available</span>
        <span><i class="legend-dot limited"></i> Limited</span>
        <span><i class="legend-dot full"></i> Fully booked</span>
        <span><i class="legend-dot unavailable"></i> Unavailable</span>
      </div>

      <p class="selected-date-label" id="selected-date-label">
        No departure date selected.
      </p>
    </div>
  `;
}

function renderBook(params) {
  const requestedSlug = params.get("package");
  const selectedPackage = getPackage(requestedSlug) || PACKAGES[0];

  const packageOptions = PACKAGES.map(pkg => `
    <option value="${escapeHtml(pkg.slug)}"
      ${pkg.slug === selectedPackage.slug ? "selected" : ""}>
      ${escapeHtml(pkg.name)} — ${peso(pkg.pricePerPerson)} / person
    </option>
  `).join("");

  return `
    <section class="section page-shell">
      <div class="container">
        <div class="page-heading">
          <p class="eyebrow">Start your next adventure</p>
          <h1>Book a trip</h1>
          <p>Choose your destination and enter your booking details.</p>
        </div>

        <div class="form-layout">
          <form class="surface booking-form" id="booking-form">

            <div class="field">
              <label for="packageSlug">Choose a tour</label>
              <select class="select" id="packageSlug"
                name="packageSlug" required>
                ${packageOptions}
              </select>
            </div>

            <div class="field">
              <label>Departure date</label>

              <input type="hidden"
                id="departureDate"
                name="departureDate">

              ${renderDepartureCalendar(selectedPackage)}
            </div>

            <div class="field">
              <label for="travelers">Number of travellers</label>
              <input class="input" id="travelers" name="travelers"
                type="number" min="1" max="10" value="1" required>
            </div>

            <div class="field">
              <label for="leadName">Full name</label>
              <input class="input" id="leadName" name="leadName"
                type="text" placeholder="Juan Dela Cruz" required>
            </div>

            <div class="field">
              <label for="email">Email address</label>
              <input class="input" id="email" name="email"
                type="email" placeholder="you@example.com" required>
            </div>

            <div class="field">
              <label for="phone">Mobile number</label>
              <input class="input" id="phone" name="phone"
                type="tel" placeholder="09171234567" required>
            </div>

            <div class="field">
              <label for="paymentMethod">Payment preference</label>
              <select class="select" id="paymentMethod"
                name="paymentMethod" required>
                ${PAYMENT_METHODS.map(method => `
                  <option value="${escapeHtml(method)}">
                    ${escapeHtml(method)}
                  </option>
                `).join("")}
              </select>
            </div>

            <div class="field">
              <label for="notes">Special requests (optional)</label>
              <textarea class="input" id="notes" name="notes"
                rows="3" maxlength="400"
                placeholder="Tell us about any special requests..."></textarea>
            </div>

            <button class="btn btn--block btn--lg" type="submit">
              Submit booking
            </button>

            <p class="hint">
              Demo booking only. No real payment will be collected.
            </p>
          </form>

          <aside class="surface booking-summary">
            <p class="eyebrow">Your selected destination</p>
            <h2>${escapeHtml(selectedPackage.name)}</h2>
            <p>${escapeHtml(selectedPackage.destination)}</p>

            <div class="summary-price">
              <span>Starting price</span>
              <strong>${peso(selectedPackage.pricePerPerson)}</strong>
              <span>per person</span>
            </div>

            <p>${selectedPackage.durationDays} days of travel</p>
            <a class="text-link" href="#/tours">Browse other tours</a>
          </aside>
        </div>
      </div>
    </section>`;
}


function renderMyBookings() {
  return `
    <section class="section page-shell">
      <div class="container">
        <div class="page-heading">
          <p class="eyebrow">Your travel details</p>
          <h1>My Bookings</h1>
          <p>Look up a booking using its reference number or email address.</p>
        </div>

        <form class="surface lookup-form" id="lookup-form">
          <div class="field">
            <label for="lookup">Booking reference or email</label>
            <input class="input" id="lookup" name="lookup"
              placeholder="LKB-... or you@example.com" required>
          </div>
          <button class="btn" type="submit">Find booking</button>
        </form>

        <div id="lookup-results"></div>
      </div>
    </section>`;
}

function renderAbout() {
  return `
    <section class="section page-shell">
      <div class="container">
        <div class="page-heading">
          <p class="eyebrow">Get to know us</p>
          <h1>About & Help</h1>
          <p>Meaningful journeys, thoughtfully planned around the Philippines.</p>
        </div>

        <div class="help-grid">
          <article class="surface help-card">
            <h2>About Lakbay</h2>
            <p>Lakbay Travel Co. is a travel website concept featuring curated
              destinations around Luzon, Visayas and Mindanao.</p>
          </article>

          <article class="surface help-card">
            <h2>How do I book?</h2>
            <p>Choose a tour, select an available departure, fill in the
              booking form and submit your demo booking.</p>
          </article>

          <article class="surface help-card">
            <h2>Where are bookings saved?</h2>
            <p>Demo bookings are stored in your browser using local storage.
              They are not sent to a real travel agency.</p>
          </article>

          <article class="surface help-card">
            <h2>Can I pay online?</h2>
            <p>No real payments are processed in this demo website.
              Payment preferences are saved only as booking information.</p>
          </article>
        </div>
      </div>
    </section>`;
}


function renderPayment(params) {
  const method = params.get("method") || "GCash";
  const reference = params.get("ref") || "Not available";

  let paymentContent = "";

  if (method.toLowerCase() === "gcash") {
    paymentContent = `
      <div class="qr-placeholder">
        <h3>Scan with GCash</h3>
        <img
          src="./images/gcash-qr.png"
          alt="GCash QR Code"
          class="payment-qr"
        >
      </div>
    `;
  } else if (method.toLowerCase() === "bank transfer") {
    paymentContent = `
      <div class="qr-placeholder">
        <h3>Bank Transfer</h3>
        <img
          src="./images/bank-qr.png"
          alt="Bank Transfer QR Code"
          class="payment-qr"
        >
      </div>
    `;
  } else if (method.toLowerCase() === "credit card") {
    paymentContent = `
      <div class="qr-placeholder">
        <h3>Credit Card Payment</h3>
        <p>
          Credit card payments are simulated for this school project.
        </p>
        <p>
          No actual card information or payment will be collected.
        </p>
      </div>
    `;
  } else {
    paymentContent = `
      <div class="qr-placeholder">
        <h3>Pay at Office</h3>
        <p>
          Please visit the booking office to settle your payment.
        </p>
      </div>
    `;
  }

  return `
    <section class="section page-shell">
      <div class="container">
        <div class="page-heading">
          <p class="eyebrow">Payment Instructions</p>
          <h1>${escapeHtml(method)} Payment</h1>
          <p>Your booking has been saved successfully!</p>
        </div>

        <article class="surface help-card">
          <p>
            <strong>Booking Reference:</strong>
            ${escapeHtml(reference)}
          </p>

          <p>
            <strong>Payment Method:</strong>
            ${escapeHtml(method)}
          </p>

          ${paymentContent}

          <p>
            <strong>Important:</strong>
            This is a school project demo. No real payment
            is processed or verified.
          </p>

          <a class="btn" href="#/my-bookings">
            View My Bookings
          </a>
        </article>
      </div>
    </section>
  `;
}

function renderRecords() {
  const bookings = getBookings();

  return `
    <section class="section page-shell">
      <div class="container">
        <div class="page-heading">
          <p class="eyebrow">Booking management</p>
          <h1>Booking Records</h1>
          <p>View and manage all customer bookings.</p>
        </div>

        <div class="surface records-panel">
          <div class="records-toolbar">
            <p><strong>${bookings.length}</strong> booking record(s)</p>
            <button class="btn" id="download-records" type="button">
              Download Records
            </button>
          </div>

          ${
            bookings.length === 0
              ? `
                <div class="empty-state">
                  <h3>No booking records yet.</h3>
                  <p>Customer bookings will appear here.</p>
                </div>
              `
              : `
                <div class="table-wrap">
                  <table class="records-table">
                    <thead>
                      <tr>
                        <th>Reference</th>
                        <th>Customer</th>
                        <th>Destination</th>
                        <th>Departure</th>
                        <th>Travellers</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${bookings.map(booking => `
                        <tr>
                          <td>${escapeHtml(booking.reference || "")}</td>
                          <td>
                            ${escapeHtml(booking.customerName || booking.name || "")}
                            <br>
                            ${escapeHtml(booking.email || "")}
                          </td>
                          <td>${escapeHtml(booking.packageName || booking.destination || "")}</td>
                          <td>${escapeHtml(booking.departureDate || "")}</td>
                          <td>${escapeHtml(String(booking.travellers || booking.travelers || 0))}</td>
                          <td>${peso(booking.total || 0)}</td>
                          <td>
                            <select
                              class="input"
                              data-status-ref="${escapeHtml(booking.reference || "")}"
                            >
                              ${STATUSES.map(status => `
                                <option
                                  value="${escapeHtml(status)}"
                                  ${booking.status === status ? "selected" : ""}
                                >
                                  ${escapeHtml(status)}
                                </option>
                              `).join("")}
                            </select>
                          </td>
                          <td>
                            <button
                              class="btn btn-small"
                              type="button"
                              data-update-ref="${escapeHtml(booking.reference || "")}"
                            >
                              Update
                            </button>
                          </td>
                        </tr>
                      `).join("")}
                    </tbody>
                  </table>
                </div>
              `
          }
        </div>
      </div>
    </section>
  `;
}

function renderRoute() {
  const { page, params } = getRoute();
  const main = document.querySelector("#main-content");

  if (page === "home") {
    main.innerHTML = renderHome();
    bindHomeEvents();
  } else if (page === "tours") {
    main.innerHTML = renderTours();
  } else if (page === "book") {
  main.innerHTML = renderBook(params);
} else if (page === "payment") {
  main.innerHTML = renderPayment(params);
} else if (page === "records") {
    main.innerHTML = renderRecords();
  } else if (page === "my-bookings") {
    main.innerHTML = renderMyBookings();
  } else if (page === "about") {
    main.innerHTML = renderAbout();
  } else {
    main.innerHTML = renderHome();
    bindHomeEvents();
  }

  bindPageEvents();
  window.scrollTo({ top: 0, behavior: "smooth" });
  updateActiveNav();
}

function updateActiveNav() {
  const { page } = getRoute();
  document.querySelectorAll(".nav-desktop a, .mobile-menu a").forEach(link => {
    const target = link.getAttribute("href").replace("#/", "");
    link.classList.toggle("is-active", target === page);
  });
}

function bindPageEvents() {
  const packageSelect = document.querySelector("#packageSlug");

  packageSelect?.addEventListener("change", () => {
    window.location.hash = `#/book?package=${encodeURIComponent(packageSelect.value)}`;
  });

  const calendar = document.querySelector("#departure-calendar");
  const monthSelect = document.querySelector("#calendarMonth");
  const dateInput = document.querySelector("#departureDate");
  const selectedDateLabel = document.querySelector("#selected-date-label");

  if (calendar && monthSelect && dateInput) {
    const updateCalendar = () => {
      document.querySelector("#calendar-grid").innerHTML =
        renderCalendarGrid(
          getPackage(document.querySelector("#packageSlug").value),
          monthSelect.value,
          dateInput.value
        );
    };

  monthSelect.addEventListener("input", updateCalendar);
  monthSelect.addEventListener("change", updateCalendar);
    calendar.addEventListener("click", event => {
      const dayButton = event.target.closest("[data-calendar-date]");

      if (!dayButton || dayButton.disabled) return;

      const date = dayButton.dataset.calendarDate;
      const selectedPackage = getPackage(
        document.querySelector("#packageSlug").value
      );

      const departure = getDepartures(selectedPackage).find(
        item => item.date === date
      );

      if (!departure || departure.isPast || departure.available <= 0) {
        return;
      }

      dateInput.value = date;

      selectedDateLabel.textContent =
        `${formatDate(date)} selected — ${departure.available} seats available`;

      updateCalendar();
    });
  }

  document.querySelector("#booking-form")?.addEventListener("submit", event => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const selectedDate = form.get("departureDate");

if (!selectedDate) {
  toast("Please select an available departure date.", "error");
  return;
}

    const result = createBooking({
      packageSlug: form.get("packageSlug"),
      departureDate: form.get("departureDate"),
      travelers: Number(form.get("travelers")),
      leadName: String(form.get("leadName")).trim(),
      email: String(form.get("email")).trim(),
      phone: String(form.get("phone")).trim(),
      paymentMethod: form.get("paymentMethod"),
      notes: String(form.get("notes") || "").trim(),
      addOnIds: []
    });

    if (!result.ok) {
      toast(result.message, "error");
      return;
    }

    const paymentMethod = result.booking.paymentMethod;

if (paymentMethod === "GCash" || paymentMethod === "Bank transfer") {
  toast("Booking created! Proceed to payment instructions.", "success");

  window.location.hash =
    `#/payment?method=${encodeURIComponent(paymentMethod)}&ref=${encodeURIComponent(result.booking.reference)}`;
} else {
  toast(`Booking created! Reference: ${result.booking.reference}`, "success");
  window.location.hash = "#/my-bookings";
}
  });

  document.querySelector("#download-records")?.addEventListener("click", () => {
    downloadRecords();
    toast("Records download started.", "success");
  });

  document.querySelectorAll("[data-update-ref]").forEach(button => {
    button.addEventListener("click", () => {
      const reference = button.dataset.updateRef;
      const select = document.querySelector(
        `[data-status-ref="${CSS.escape(reference)}"]`
      );

      if (!select) return;

      const result = changeStatus(reference, select.value);

      if (!result.ok) {
        toast(result.message, "error");
        return;
      }

      toast("Booking status updated.", "success");
      renderRoute();
    });
  });

  document.querySelector("#lookup-form")?.addEventListener("submit", event => {
    event.preventDefault();

    const term = document.querySelector("#lookup").value.trim().toLowerCase();
    const matches = getBookings().filter(booking =>
      booking.reference.toLowerCase() === term ||
      booking.email.toLowerCase() === term
    );

    const results = document.querySelector("#lookup-results");

    
results.innerHTML = matches.length ? matches.map(booking => `
  <article class="surface lookup-result">
    <div class="booking-summary-header">
      <div>
        <p class="eyebrow">BOOKING CONFIRMATION</p>
        <h2>${escapeHtml(booking.packageName)}</h2>
        <p>${escapeHtml(booking.destination)}</p>
      </div>
      ${statusBadge(booking.status)}
    </div>

    <div class="booking-reference">
      <span>Booking Reference</span>
      <strong>${escapeHtml(booking.reference)}</strong>
    </div>

    <div class="booking-summary-details">
      <p><strong>Departure:</strong> ${formatDate(booking.departureDate)}</p>
      <p><strong>Travellers:</strong> ${booking.travelers}</p>
      <p><strong>Payment Method:</strong> ${escapeHtml(booking.paymentMethod || "Not specified")}</p>
      <p><strong>Total:</strong> ${peso(booking.costs?.total || 0)}</p>
      <p><strong>Created:</strong> ${formatDateTime(booking.createdAt)}</p>
      <p><strong>Add-ons:</strong> ${escapeHtml(addOnSummary(booking.addOnIds || []).join(", ") || "None")}</p>
    </div>
  </article>
`).join("") : `
  <div class="empty-state">
    <h3>No booking found</h3>
    <p>Check the reference number or email and try again.</p>
  </div>`;
  });
}

function bindShellEvents() {
  const toggle = document.querySelector("#menu-toggle");
  const menu = document.querySelector("#mobile-menu");

  toggle?.addEventListener("click", () => {
    const open = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!open));
    menu.hidden = open;
  });

  document.querySelectorAll(".mobile-menu a").forEach(link => {
    link.addEventListener("click", () => {
      menu.hidden = true;
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function startApp() {
  app.innerHTML = `
    ${renderHeader()}
    <main id="main-content"></main>
    ${renderFooter()}
    <div class="toast-region" id="toast-region"
      aria-live="polite" aria-atomic="true"></div>
  `;

  bindShellEvents();
  renderRoute();
  window.addEventListener("hashchange", renderRoute);
}

startApp();
