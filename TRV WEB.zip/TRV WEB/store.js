/**
 * Nature Gateway — booking store
 * Pricing, business rules, validation and localStorage persistence.
 */

import { ADD_ONS, getAddOn, getPackage, PACKAGES } from "./data.js";

export const STORAGE_KEY = "lakbay.bookings.v1";
export const BOOKING_FEE_RATE = 0.05;
export const MAX_TRAVELERS = 10;
export const STATUSES = ["Pending", "Confirmed", "Completed", "Cancelled"];
export const PAYMENT_METHODS = ["GCash", "Bank transfer", "Credit card", "Pay at office"];

export const STATUS_TRANSITIONS = {
  Pending: ["Confirmed", "Cancelled"],
  Confirmed: ["Completed", "Cancelled"],
  Completed: [],
  Cancelled: [],
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;
const PHONE_PATTERN = /^(09\d{9}|\+639\d{9})$/;
const NAME_PATTERN = /^[A-Za-zñÑ.'\-\s]+$/;

/* ------------------------------------------------------------------ */
/* Dates & formatting                                                  */
/* ------------------------------------------------------------------ */

const pad = (value) => String(value).padStart(2, "0");

export function toISODate(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function todayISO() {
  return toISODate(new Date());
}

export function addDaysISO(offsetDays, from = new Date()) {
  const next = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  next.setDate(next.getDate() + offsetDays);
  return toISODate(next);
}

/** Parses YYYY-MM-DD as a local calendar date (avoids UTC off-by-one). */
export function parseISODate(iso) {
  const [year, month, day] = String(iso).split("-").map(Number);
  return new Date(year, (month || 1) - 1, day || 1);
}

export function formatDate(iso, options = {}) {
  if (!iso) return "—";
  return parseISODate(iso).toLocaleDateString("en-PH", {
    month: "short",
    day: "numeric",
    year: "numeric",
    ...options,
  });
}

export function formatLongDate(iso) {
  if (!iso) return "—";
  return formatDate(iso, { weekday: "short", month: "long", day: "numeric", year: "numeric" });
}
export function formatDateTime(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-PH", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function daysUntil(iso) {
  if (!iso) return 0;
  const target = parseISODate(iso).getTime();
  const today = parseISODate(todayISO()).getTime();
  return Math.round((target - today) / 86400000);
}

const PESO = new Intl.NumberFormat("en-PH", {
  style: "currency",
  currency: "PHP",
  maximumFractionDigits: 0,
});

export function peso(value) {
  return PESO.format(Number.isFinite(value) ? value : 0);
}

export function pluralize(count, singular, plural = `${singular}s`) {
  return `${count} ${count === 1 ? singular : plural}`;
}
/* ------------------------------------------------------------------ */
/* Availability & pricing                                              */
/* ------------------------------------------------------------------ */

export const isActive = (booking) => booking.status !== "Cancelled";

export function getDepartures(pkg, bookings = getBookings()) {
  const today = todayISO();
  return pkg.departures
    .map((schedule) => {
      const date = addDaysISO(schedule.offsetDays);
      const booked = bookings
        .filter((booking) => booking.packageSlug === pkg.slug && booking.departureDate === date && isActive(booking))
        .reduce((sum, booking) => sum + booking.travelers, 0);
      return {
        date,
        seats: schedule.seats,
        booked,
        available: Math.max(0, schedule.seats - booked),
        isPast: date < today,
      };
    })
    .sort((a, b) => a.date.localeCompare(b.date));
}
export function getAvailableSeats(packageSlug, departureDate, bookings = getBookings(), excludeReference) {
  const pkg = getPackage(packageSlug);
  if (!pkg) return 0;
  const departure = getDepartures(pkg, bookings).find((item) => item.date === departureDate);
  if (!departure || departure.isPast) return 0;
  const excluded = excludeReference
    ? bookings.find((booking) => booking.reference === excludeReference)
    : null;
  return Math.max(0, departure.available + (excluded && isActive(excluded) ? excluded.travelers : 0));
}

export function calculateCosts(pkg, travelers, addOnIds = []) {
  const count = Math.max(1, Number(travelers) || 1);
  const subtotal = pkg.pricePerPerson * count;
  const addOnTotal = addOnIds.reduce((sum, id) => {
    const addOn = getAddOn(id);
    if (!addOn) return sum;
    return sum + (addOn.perPerson ? addOn.price * count : addOn.price);
  }, 0);
  const serviceFee = Math.round(subtotal * BOOKING_FEE_RATE);
  return { subtotal, addOnTotal, serviceFee, total: subtotal + addOnTotal + serviceFee };
}

export function findDuplicateBooking(bookings, email, packageSlug, departureDate, excludeReference) {
  const normalized = String(email || "").trim().toLowerCase();
  return (
    bookings.find(
      (booking) =>
        isActive(booking) &&
        booking.reference !== excludeReference &&
        booking.packageSlug === packageSlug &&
        booking.departureDate === departureDate &&
        booking.email.trim().toLowerCase() === normalized,
    ) || null
  );
  }

/* ------------------------------------------------------------------ */
/* Validation                                                          */
/* ------------------------------------------------------------------ */

export const isValidEmail = (value) => EMAIL_PATTERN.test(String(value || "").trim());
export const isValidPhone = (value) => PHONE_PATTERN.test(String(value || "").trim());

/**
 * Validates a booking form. Returns an object keyed by field name.
 * Business capacity/duplicate rules are also enforced when saving.
 */
export function validateBooking(values) {
  const errors = {};
  const travelers = Number(values.travelers);
  const pkg = getPackage(values.packageSlug);

  if (!pkg) {
    errors.packageSlug = "Choose a tour package.";
  }

  if (!values.departureDate) {
    errors.departureDate = "Choose an available departure date.";
  } else if (!pkg) {
    errors.departureDate = "Choose a tour first.";
  } else {
    const departure = getDepartures(pkg).find((item) => item.date === values.departureDate);
    if (!departure) {
      errors.departureDate = "That date is not part of this tour's schedule.";
    } else if (departure.isPast) {
      errors.departureDate = "Past departure dates cannot be booked.";
    } else if (departure.available === 0) {
      errors.departureDate = "That departure is fully booked. Choose another date.";
    }
  }
  if (!Number.isInteger(travelers) || travelers < 1) {
    errors.travelers = "At least one traveller is required.";
  } else if (travelers > MAX_TRAVELERS) {
    errors.travelers = `Groups are capped at ${MAX_TRAVELERS} travellers.`;
  }

  const name = String(values.leadName || "").trim();
  if (name.length < 3) {
    errors.leadName = "Enter your full name.";
  } else if (!NAME_PATTERN.test(name)) {
    errors.leadName = "Use letters, spaces, hyphens and apostrophes only.";
  } else if (name.split(/\s+/).filter(Boolean).length < 2) {
    errors.leadName = "Enter both your first and last name.";
  }

  const email = String(values.email || "").trim();
  if (!email) {
    errors.email = "Email is required.";
  } else if (!isValidEmail(email)) {
    errors.email = "Enter a valid email address, e.g. you@email.com.";
  }

  const phone = String(values.phone || "").trim();
  if (!phone) {
    errors.phone = "Mobile number is required.";
  } else if (!isValidPhone(phone)) {
    errors.phone = "Use 09XXXXXXXXX or +639XXXXXXXXX.";
  }

  if (String(values.notes || "").length > 400) {
    errors.notes = "Keep special requests under 400 characters.";
  }
   if (!PAYMENT_METHODS.includes(values.paymentMethod)) {
    errors.paymentMethod = "Choose a payment preference.";
  }

  return errors;
}

export function statusIsLocked(status) {
  return status === "Completed" || status === "Cancelled";
}

export function canTransition(booking, next) {
  if (booking.status === next) {
    return { allowed: false, message: "That is already the current status." };
  }
  if (!STATUS_TRANSITIONS[booking.status].includes(next)) {
    return {
      allowed: false,
      message: `A ${booking.status.toLowerCase()} booking cannot be marked as ${next.toLowerCase()}.`,
    };
  }
  if (next === "Confirmed" && daysUntil(booking.departureDate) < 0) {
    return {
      allowed: false,
      message: "Departure date has already passed — this booking can only be cancelled.",
    };
  }
  if (next === "Completed" && daysUntil(booking.departureDate) > 0) {
    return {
      allowed: false,
      message: "A trip can only be marked completed on or after its departure date.",
    };
  }
  return { allowed: true };
}
/* ------------------------------------------------------------------ */
/* Persistence                                                         */
/* ------------------------------------------------------------------ */

let memoryRecords = null;

function storageAvailable() {
  try {
    const probe = "__lakbay_probe__";
    window.localStorage.setItem(probe, "1");
    window.localStorage.removeItem(probe);
    return true;
  } catch {
    return false;
  }
}

function isoHoursAgo(hours) {
  return new Date(Date.now() - hours * 3600000).toISOString();
}

function isValidBooking(value) {
  return Boolean(
    value &&
      typeof value === "object" &&
      typeof value.reference === "string" &&
      typeof value.packageSlug === "string" &&
      typeof value.departureDate === "string" &&
      typeof value.travelers === "number" &&
      typeof value.email === "string" &&
      value.costs &&
      typeof value.status === "string",
  );
}
export function buildSampleBookings() {
  const samples = [
    {
      reference: "LKB-SAMPLE-4821",
      packageSlug: "el-nido-island-odyssey",
      departureIndex: 0,
      travelers: 2,
      leadName: "Maria Santos",
      email: "maria.santos@email.com",
      phone: "09171234567",
      addOnIds: ["airfare", "insurance"],
      notes: "Celebrating an anniversary — a quiet room would be lovely.",
      paymentMethod: "GCash",
      status: "Confirmed",
      createdAt: isoHoursAgo(74),
    },
    {
      reference: "LKB-SAMPLE-9157",
      packageSlug: "sagada-highlands-trek",
      departureIndex: 1,
      travelers: 1,
      leadName: "Joshua Reyes",
      email: "joshua.reyes@email.com",
      phone: "09183219876",
      addOnIds: ["insurance", "transfer"],
      notes: "Vegetarian meals for the whole trip.",
      paymentMethod: "Bank transfer",
      status: "Pending",
      createdAt: isoHoursAgo(28),
    },
    {
        reference: "LKB-SAMPLE-3308",
      packageSlug: "bohol-countryside-escape",
      departureIndex: 2,
      travelers: 3,
      leadName: "Ana Villanueva",
      email: "ana.villanueva@email.com",
      phone: "09205551234",
      addOnIds: [],
      notes: "Travelling with two children, ages 7 and 10.",
      paymentMethod: "Pay at office",
      status: "Cancelled",
      createdAt: isoHoursAgo(140),
    },
  ];
   return samples
    .map((sample) => {
      const pkg = getPackage(sample.packageSlug);
      if (!pkg) return null;
      const schedule = pkg.departures[sample.departureIndex] || pkg.departures[0];
      const departureDate = addDaysISO(schedule.offsetDays);
      return {
        reference: sample.reference,
        packageSlug: sample.packageSlug,
        packageName: pkg.name,
        destination: pkg.destination,
        departureDate,
        travelers: sample.travelers,
        leadName: sample.leadName,
        email: sample.email,
        phone: sample.phone,
        addOnIds: sample.addOnIds,
        notes: sample.notes,
        paymentMethod: sample.paymentMethod,
        costs: calculateCosts(pkg, sample.travelers, sample.addOnIds),
        status: sample.status,
        createdAt: sample.createdAt,
        updatedAt: sample.createdAt,
        isSample: true,
        history: [
          { status: sample.status, at: sample.createdAt, note: "Sample record created for demonstration" },
        ],
      };
    })
    .filter(Boolean);
}
export function getBookings() {
  if (!storageAvailable()) {
    if (!memoryRecords) memoryRecords = buildSampleBookings();
    return [...memoryRecords];
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const seeded = buildSampleBookings();
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
      return seeded;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isValidBooking)
      .map((booking) => ({ ...booking, history: Array.isArray(booking.history) ? booking.history : [] }))
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  } catch {
    return [];
  }
}

export function saveBookings(bookings) {
  memoryRecords = [...bookings];
  if (!storageAvailable()) return false;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
    return true;
  } catch {
    return false;
  }
}
export function findBooking(reference) {
  return getBookings().find((booking) => booking.reference === reference) || null;
}

function makeReference(bookings) {
  const stamp = todayISO().replaceAll("-", "").slice(2);
  let reference;
  do {
    reference = `LKB-${stamp}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  } while (bookings.some((booking) => booking.reference === reference));
  return reference;
}

/* ------------------------------------------------------------------ */
/* Transactions                                                        */
/* ------------------------------------------------------------------ */

const fail = (message) => ({ ok: false, message });

export function createBooking(input) {
  const bookings = getBookings();
  const pkg = getPackage(input.packageSlug);
  if (!pkg) return fail("Please choose a tour package before submitting.");

  const departure = getDepartures(pkg, bookings).find((item) => item.date === input.departureDate);
  if (!departure) {
    return fail("That travel date is not part of this tour's schedule. Please select an available departure.");
  }
  if (departure.isPast) {
    return fail("Past departure dates cannot be booked. Please choose an upcoming departure.");
  }
  if (!isValidEmail(input.email)) {
    return fail("Please enter a valid email address so we can send your confirmation.");
  }
  if (!isValidPhone(input.phone)) {
    return fail("Please enter a valid mobile number (e.g. 09171234567).");
  }
  if (!Number.isInteger(Number(input.travelers)) || input.travelers < 1 || input.travelers > MAX_TRAVELERS) {
    return fail(`Group size must be a whole number from 1 to ${MAX_TRAVELERS}.`);
  }
  if (departure.available < input.travelers) {
    return fail(
      `Only ${departure.available} seat${departure.available === 1 ? "" : "s"} remain on that departure. Reduce your group size or pick another date.`,
    );
  }
  const duplicate = findDuplicateBooking(bookings, input.email, pkg.slug, input.departureDate);
  if (duplicate) {
    return fail(
      `This email already holds booking ${duplicate.reference} for that departure. Duplicate slot reservations are blocked.`,
    );
  }
   const now = new Date().toISOString();
  const booking = {
    ...input,
    travelers: Number(input.travelers),
    reference: makeReference(bookings),
    packageName: pkg.name,
    destination: pkg.destination,
    costs: calculateCosts(pkg, input.travelers, input.addOnIds),
    status: "Pending",
    createdAt: now,
    updatedAt: now,
    history: [{ status: "Pending", at: now, note: "Booking submitted" }],
  };

  saveBookings([booking, ...bookings]);
  return { ok: true, booking };
}

export function updateBooking(reference, patch) {
  const bookings = getBookings();
  const current = bookings.find((booking) => booking.reference === reference);
  if (!current) return fail("That booking record could not be found.");
  if (statusIsLocked(current.status)) {
    return fail(`${current.status} records are read-only. Only pending or confirmed bookings can be edited.`);
  }

  const pkg = getPackage(current.packageSlug);
  if (!pkg) return fail("The tour package for this record is no longer available.");

  const nextDepartureDate = patch.departureDate || current.departureDate;
  const nextTravelers = Number(patch.travelers ?? current.travelers);
  const nextEmail = patch.email ?? current.email;
  const nextPhone = patch.phone ?? current.phone;
    const departure = getDepartures(pkg, bookings).find((item) => item.date === nextDepartureDate);
  if (!departure || departure.isPast) {
    return fail("Please choose an upcoming departure from this tour's schedule.");
  }
  if (!Number.isInteger(nextTravelers) || nextTravelers < 1 || nextTravelers > MAX_TRAVELERS) {
    return fail(`Group size must be a whole number from 1 to ${MAX_TRAVELERS}.`);
  }
  if (!isValidEmail(nextEmail)) return fail("Please enter a valid email address.");
  if (!isValidPhone(nextPhone)) return fail("Please enter a valid mobile number (e.g. 09171234567).");

  const available = getAvailableSeats(current.packageSlug, nextDepartureDate, bookings, reference);
  if (available < nextTravelers) {
    return fail(`Only ${available} seat${available === 1 ? "" : "s"} are available for that departure.`);
  }

  const duplicate = findDuplicateBooking(bookings, nextEmail, current.packageSlug, nextDepartureDate, reference);
  if (duplicate) {
    return fail(`This email already has booking ${duplicate.reference} for that departure.`);
  }

  const updated = {
    ...current,
    ...patch,
    departureDate: nextDepartureDate,
    travelers: nextTravelers,
    costs: calculateCosts(pkg, nextTravelers, patch.addOnIds ?? current.addOnIds),
    updatedAt: new Date().toISOString(),
  };

  saveBookings(bookings.map((booking) => (booking.reference === reference ? updated : booking)));
  return { ok: true, booking: updated };
}
export function changeStatus(reference, next) {
  const bookings = getBookings();
  const current = bookings.find((booking) => booking.reference === reference);
  if (!current) return fail("That booking record could not be found.");

  const check = canTransition(current, next);
  if (!check.allowed) return fail(check.message || "That status change is not allowed.");

  const now = new Date().toISOString();
  const updated = {
    ...current,
    status: next,
    updatedAt: now,
    history: [...current.history, { status: next, at: now }],
  };

  saveBookings(bookings.map((booking) => (booking.reference === reference ? updated : booking)));
  return { ok: true, booking: updated };
}

export function deleteBooking(reference) {
  const bookings = getBookings();
  const current = bookings.find((booking) => booking.reference === reference);
  if (!current) return fail("That booking record could not be found.");
  saveBookings(bookings.filter((booking) => booking.reference !== reference));
  return { ok: true, booking: current };
}

export function resetSamples() {
  const seeded = buildSampleBookings();
  saveBookings(seeded);
  return seeded;
}
export function addOnSummary(addOnIds = []) {
  return addOnIds.map((id) => getAddOn(id)?.label).filter(Boolean);
}

export function downloadRecords() {
  const bookings = getBookings();
  if (!bookings.length) return false;
  const payload = {
    exportedAt: new Date().toISOString(),
    system: "Lakbay Travel Co. front-end booking records",
    count: bookings.length,
    bookings,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `lakbay-bookings-${todayISO()}.json`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  return true;
}

/** Used by the help page to describe the catalogue totals. */
export const catalogueStats = () => ({
  routes: PACKAGES.length,
  departures: PACKAGES.reduce((sum, pkg) => sum + pkg.departures.length, 0),
  addOns: ADD_ONS.length,
});
