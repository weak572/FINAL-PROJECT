NATURE GATEWAY — RUNNING INSTRUCTIONS

IMPORTANT:
This project uses JavaScript ES Modules and must be opened through a local development server.

HOW TO RUN:
1. Open the Nature Gateway project folder in Visual Studio Code.
2. Make sure the Live Server extension is installed.
3. Locate and right-click `index.html`.
4. Select "Open with Live Server".
5. The website will open in your browser.

NOTE:
Do not open index.html directly using file:// because JavaScript modules require an HTTP server.

The project is a demonstration booking website. No real payments are collected.